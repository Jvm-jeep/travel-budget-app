import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  cities = ['Delhi', 'Paris', 'Tokyo'];
  selectedCity = '';
  cityData: any = null;
  totalBudget = 0;

  constructor(private http: HttpClient) {}

  fetchCityData() {
    if (!this.selectedCity) return;
    this.http.get(`http://localhost:3000/api/location/${this.selectedCity.toLowerCase()}`).subscribe((data: any) => {
      this.cityData = data;
      this.totalBudget = data.hotels[0].price + data.food[0].price + data.petrolPrice + data.bookings.flight;
    });
  }
}
