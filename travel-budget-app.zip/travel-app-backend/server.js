const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());

const data = {
  delhi: {
    currency: 'INR',
    symbol: '₹',
    hotels: [{ name: 'Taj Palace', price: 5000 }],
    food: [{ name: 'Chole Bhature', price: 150 }],
    attractions: ['India Gate', 'Red Fort'],
    petrolPrice: 105,
    bookings: {
      train: 800,
      bus: 500,
      flight: 4000,
    },
  },
  paris: {
    currency: 'EUR',
    symbol: '€',
    hotels: [{ name: 'Hotel Parisienne', price: 120 }],
    food: [{ name: 'Croissant', price: 4 }],
    attractions: ['Eiffel Tower', 'Louvre Museum'],
    petrolPrice: 1.85,
    bookings: {
      train: 30,
      bus: 15,
      flight: 100,
    },
  },
  tokyo: {
    currency: 'JPY',
    symbol: '¥',
    hotels: [{ name: 'Tokyo Inn', price: 10000 }],
    food: [{ name: 'Sushi Set', price: 1200 }],
    attractions: ['Shibuya Crossing', 'Tokyo Tower'],
    petrolPrice: 170,
    bookings: {
      train: 1500,
      bus: 800,
      flight: 9000,
    },
  },
};

app.get('/api/location/:city', (req, res) => {
  const city = req.params.city.toLowerCase();
  const info = data[city];
  if (info) {
    res.json(info);
  } else {
    res.status(404).json({ error: 'City not found' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
